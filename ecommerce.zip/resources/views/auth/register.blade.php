<x-app-layout>
    <div class="align-middle max-w-96 mx-auto my-36">
        <div class="text-xl font-bold">Sign in</div>
        <form method="POST" action="{{ route('register') }}">
            @csrf

            <div class="my-4">
                <input class="w-full" type="text" name="name" id="name" required placeholder="Name">
            </div>

            <div class="my-4">
                <input class="w-full" type="email" name="email" id="email" required placeholder="Email">
            </div>

            <div class="my-4">
                <input class="w-full" type="password" name="password" id="password" required placeholder="Password">
            </div>

            <div class="my-4">
                <input class="w-full" type="password" name="password_confirmation" id="password_confirmation" required placeholder="Confirm Password">
            </div>

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800" href="{{ route('login') }}">
                    {{ __('Already registered?') }}
                </a>

                <x-primary-button class="ms-4">
                    {{ __('Register') }}
                </x-primary-button>
            </div>
        </form>
    </div>
</x-app-layout>

