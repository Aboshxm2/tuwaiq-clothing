<x-app-layout>
    <div>
        <div>
            <form action="">
                @csrf
                <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
        </div>

        <div class="grid grid-cols-3">
            @foreach($products as $product)
                <x-product :$product></x-product>
                <x-product :$product></x-product>
                <x-product :$product></x-product>
            @endforeach
        </div>
    </div>
</x-app-layout>
