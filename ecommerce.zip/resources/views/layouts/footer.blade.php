<div class="py-6 text-2xl shadow-inner">
    <div class="py-3">
        <ul class="flex justify-center gap-12">
            <li>{{ __("About Us") }}</li>
            <li>{{ __("Support") }}</li>
            <li>{{ __("Contact Us") }}</li>
            <li>{{ __("Terms of Service") }}</li>
        </ul>
    </div>
    <div class="py-3">
        <ul class="flex justify-center gap-12">
            <li><i class="fa-brands fa-instagram"></i></li>
            <li><i class="fa-brands fa-facebook"></i></li>
            <li><i class="fa-solid fa-x"></i></li>
            <li><i class="fa-brands fa-youtube"></i></li>
        </ul>
    </div>
</div>
