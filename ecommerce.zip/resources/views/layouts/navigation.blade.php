<nav>
    <div class="sm:p-5 p-3 grid grid-cols-3 justify-center items-center shadow">
        <div>{{ __("lang") }}</div>
        <a href="{{ route('home') }}"><img src="/logo/logo.png" alt="" width="250" class="mx-auto"></a>
        <div>
            <ul class="flex justify-end">
                <li><i class="px-3 fa-solid fa-magnifying-glass"></i></li>
                <li><i class="px-3 fa-solid fa-user"></i></li>
                <li><a href="{{ route('cart.index') }}"><i class="px-3 fa-solid fa-cart-shopping"></i></a></li>
            </ul>
        </div>
    </div>
    <div class="py-3 shadow">
        <ul class="flex justify-center items-center gap-x-16">
            @foreach($groups as $group)
                <li class="dropdown flex relative flex-col justify-between items-start">
                    <div>{{ __($group->name) }}</div>
                    <div class="hidden rounded z-10 p-3 absolute top-full bg-white shadow">
                        <ul class="flex flex-col gap-6">
                            @foreach($group->categories()->get() as $category)
                                <li>{{ $category->name }}</li>
                            @endforeach
                        </ul>
                    </div>
                </li>
            @endforeach
        </ul>
    </div>
</nav>
<style>
    .dropdown:hover > * {display: block}
</style>
