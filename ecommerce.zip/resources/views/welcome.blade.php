@php use App\Models\Product; @endphp
<x-app-layout>
    <div class="h-[calc(100vh-250px)] bg-cover" style="background-image: url('hero.png');">
        <h1 class="relative float-left top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white text-9xl font-bold">
            {{ __("hero text") }}
        </h1>
    </div>
    @php($products = Product::all())
    <x-product-slider heading="Summer" :$products></x-product-slider>
    <x-product-slider heading="Winter" :products="[]"></x-product-slider>
    <x-product-slider heading="Cool" :products="[]"></x-product-slider>
    <x-product-slider heading="Children" :products="[]"></x-product-slider>
</x-app-layout>
