<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index(Request $request)
    {
        return view('cart', ["cart" => json_decode($request->cookie("cart", "{}"), true)]);
    }

    public function add(Request $request)
    {
        $cart = json_decode($request->cookie('cart') ?? "{}", true);

        $cart[$request->variant] = $request->count ?? 1;

        return redirect()->route("cart.index")->withCookie(cookie('cart', json_encode($cart)));
    }

    public function remove(Request $request)
    {
        $cart = json_decode($request->cookie('cart') ?? "{}", true);

        if(isset($cart[$request->variant]))
            unset($cart[$request->variant]);

        return redirect()->route("cart.index")->withCookie(cookie('cart', json_encode($cart)));
    }
}
