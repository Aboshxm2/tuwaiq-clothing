<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Group;
use App\Models\Product;
use App\Models\Tag;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function index(Request $request)
    {
        if(isset($request->name)) {
            $query = Product::where('name', "LIKE", "%{$request->name}%");
        }else if(isset($request->groups)) {
            $query = Group::where('id', 'IN', $request->groups)->products();
        }else if(isset($request->categories)) {
            $query = Category::where('id', 'IN', $request->categories)->products();
        }else if(isset($request->tags)) {
            $query = Tag::where('id', 'IN', $request->tags)->products();
        }

        return view('search', ["products" => isset($query)? $query->get(): Product::all()]);
    }
}
